﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Bonobo.Git.Server
{
    public static class Definitions
    {
        public static class Roles
        {
            public const string Administrator = "Administrator";
            public const string Member = "Member";
        }
    }
}