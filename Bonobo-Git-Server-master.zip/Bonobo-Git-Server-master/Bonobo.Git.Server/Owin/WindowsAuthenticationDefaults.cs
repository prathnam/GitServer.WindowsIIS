﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Bonobo.Git.Server.Owin.Windows
{
    public class WindowsAuthenticationDefaults
    {
        public static readonly string AuthenticationType = "Windows";
    }
}