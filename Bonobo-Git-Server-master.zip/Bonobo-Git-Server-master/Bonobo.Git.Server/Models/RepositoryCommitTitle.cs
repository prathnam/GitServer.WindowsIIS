﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Bonobo.Git.Server.Models
{
    public class RepositoryCommitTitleModel
    {
        public string ShortTitle { get; set; }

        public string ExtraTitle { get; set; }
    }
}